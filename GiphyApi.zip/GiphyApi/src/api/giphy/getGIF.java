package api.giphy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;

import org.apache.http.client.ClientProtocolException;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;

import org.apache.http.entity.StringEntity;

import org.apache.http.impl.client.DefaultHttpClient;

@WebServlet("/getGIF")
public class getGIF extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public getGIF() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String query = request.getParameter("query");
			URL url = new URL(
					"http://api.giphy.com/v1/stickers/search?api_key=OFDktlTUE8GWDJcsMLl2pxONVBMfCOcW&q="+query+"");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			conn.setConnectTimeout(10000);
			System.out.println(conn.getResponseCode());

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");
			response.setContentType("application/json");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
				PrintWriter pw = response.getWriter();
				pw.write(output);
				pw.close();
			}

			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}

		// HttpClient client = new DefaultHttpClient();
		// HttpGet req = new HttpGet(
		// "http://api.giphy.com/v1/stickers/search?api_key=OFDktlTUE8GWDJcsMLl2pxONVBMfCOcW&q=pan&limit=5");
		//
		// HttpResponse res = client.execute(req);
		//
		// BufferedReader rd = new BufferedReader(new
		// InputStreamReader(res.getEntity().getContent()));
		//
		// String line = "";
		//
		// while ((line = rd.readLine()) != null) {
		//
		// System.out.println(line);
		// }

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
