document.getElementById('searchButton').addEventListener("click",function(){
	var query = document.getElementById("query").value;
	var template = '<iframe src="{{url}}" width="480" height="320" frameBorder="0" class="giphy-embed" allowFullScreen></iframe>';
	var resultString = "";
	var xhr = new XMLHttpRequest();
	xhr.open("GET","getGIF?query="+query);
	xhr.send();
	xhr.onreadystatechange = function(){
		if(this.status == 200 && this.readyState == 4){
			var json = JSON.parse(this.responseText);
			json = json['data'];
			if(json.length == 0){
				resultString += "Nothing Found";
			}
			console.log(json);
			for(var i=0;i<json.length;i++){
				resultString += template.replace("{{url}}",json[i]["images"]['fixed_height']['url']);
				console.log(json[i]['url']);
			}
			document.getElementById("result").innerHTML = resultString;
		}
	}
});